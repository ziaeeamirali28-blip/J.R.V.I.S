package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
        val isRunning get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() {}

    // ─── PUBLIC API ───────────────────────────────────────────

    /** Type text into the currently focused / first EditText on screen */
    fun typeText(text: String, delayMs: Long = 600, onDone: (() -> Unit)? = null) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val editText = findFirstEditText(root)
            if (editText != null) {
                editText.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle()
                args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
                )
                editText.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                onDone?.invoke()
            }
        }, delayMs)
    }

    /** Click a node whose content description or text contains the given string */
    fun clickByLabel(label: String, delayMs: Long = 300, onDone: (() -> Unit)? = null) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val node = findNodeByLabel(root, label)
            node?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            onDone?.invoke()
        }, delayMs)
    }

    /** Tap at absolute screen coordinates */
    fun tapAt(x: Float, y: Float, delayMs: Long = 0) {
        Handler(Looper.getMainLooper()).postDelayed({
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        }, delayMs)
    }

    /** Scroll down on screen */
    fun scrollDown(delayMs: Long = 0) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val scrollable = findScrollable(root)
            scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }, delayMs)
    }

    /** Press the BACK button */
    fun pressBack() = performGlobalAction(GLOBAL_ACTION_BACK)

    /** Press HOME */
    fun pressHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    /** Open recents */
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    // ─── WhatsApp automation ──────────────────────────────────

    /**
     * Opens WhatsApp, searches for the contact, opens the chat, and sends a message.
     * Requires WhatsApp to be installed.
     */
    fun sendWhatsApp(contact: String, message: String) {
        // Step 1: open WhatsApp
        val ctx = applicationContext
        val intent = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")
            ?: return  // WhatsApp not installed
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)

        // Step 2: tap search icon (content-desc "Search" in WhatsApp)
        clickByLabel("Search", delayMs = 1800) {
            // Step 3: type contact name
            typeText(contact, delayMs = 600) {
                // Step 4: click first result
                Handler(Looper.getMainLooper()).postDelayed({
                    val root = rootInActiveWindow ?: return@postDelayed
                    val result = findFirstClickableListItem(root)
                    result?.performAction(AccessibilityNodeInfo.ACTION_CLICK)

                    // Step 5: type message and send
                    typeText(message, delayMs = 1200) {
                        clickByLabel("Send", delayMs = 500)
                    }
                }, 1000)
            }
        }
    }

    // ─── Telegram automation ──────────────────────────────────

    fun sendTelegram(contact: String, message: String) {
        val ctx = applicationContext
        val intent = ctx.packageManager.getLaunchIntentForPackage("org.telegram.messenger")
            ?: return
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)

        clickByLabel("Search", delayMs = 1800) {
            typeText(contact, delayMs = 600) {
                Handler(Looper.getMainLooper()).postDelayed({
                    val root = rootInActiveWindow ?: return@postDelayed
                    val result = findFirstClickableListItem(root)
                    result?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    typeText(message, delayMs = 1200) {
                        clickByLabel("Send", delayMs = 500)
                    }
                }, 1000)
            }
        }
    }

    // ─── Web form filler ─────────────────────────────────────

    /**
     * Fills web form fields in the active browser window.
     * fields: list of Pair(fieldHint/label, value)
     */
    fun fillWebForm(fields: List<Pair<String, String>>, delayMs: Long = 800) {
        Handler(Looper.getMainLooper()).postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val editTexts = findAllEditTexts(root)
            editTexts.forEachIndexed { i, node ->
                if (i < fields.size) {
                    val args = Bundle()
                    args.putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        fields[i].second
                    )
                    node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                }
            }
        }, delayMs)
    }

    // ─── Node finders ────────────────────────────────────────

    private fun findFirstEditText(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.className == "android.widget.EditText") return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findFirstEditText(it)?.let { r -> return r } }
        }
        return null
    }

    private fun findAllEditTexts(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        if (node.className == "android.widget.EditText") result.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { result.addAll(findAllEditTexts(it)) }
        }
        return result
    }

    private fun findNodeByLabel(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val cd = node.contentDescription?.toString() ?: ""
        val txt = node.text?.toString() ?: ""
        if ((cd.contains(label, true) || txt.contains(label, true)) && node.isClickable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findNodeByLabel(it, label)?.let { r -> return r } }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findScrollable(it)?.let { r -> return r } }
        }
        return null
    }

    private fun findFirstClickableListItem(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isClickable &&
            (node.className?.contains("ListView") == false) &&
            (node.className?.contains("RecyclerView") == false)) {
            return node
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                if (child.isClickable) return child
                findFirstClickableListItem(child)?.let { return it }
            }
        }
        return null
    }
}
