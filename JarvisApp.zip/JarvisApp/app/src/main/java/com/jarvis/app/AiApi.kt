package com.jarvis.app

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Unified AI API client using GapGPT (OpenAI-compatible endpoint).
 * Supports switching between GPT, Claude, Gemini, and other models
 * just by changing the model name — same endpoint, same auth.
 */
object AiApi {

    // GapGPT base URL (OpenAI-compatible)
    // Use https://api.gapapi.com/v1 if you need the external CDN endpoint instead
    private const val BASE_URL = "https://api.gapgpt.app/v1/chat/completions"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Available models — easy to extend
    enum class AiModel(val id: String, val displayName: String) {
        GPT4O("gpt-4o", "GPT-4o"),
        GPT4O_MINI("gpt-4o-mini", "GPT-4o Mini"),
        CLAUDE_SONNET("claude-sonnet-4-6", "Claude Sonnet"),
        CLAUDE_OPUS("claude-opus-4-7", "Claude Opus"),
        GEMINI_PRO("gemini-2.5-pro", "Gemini 2.5 Pro"),
        GEMINI_FLASH("gemini-2.5-flash", "Gemini Flash")
    }

    private val SYSTEM_PROMPT = """
You are J.A.R.V.I.S — Just A Rather Very Intelligent System — Tony Stark's personal AI assistant.

PERSONALITY:
- Sophisticated, calm British manner. Address user as "sir" or "ma'am".
- Witty, precise, extremely capable. Never say you can't without offering an alternative.
- You ARE JARVIS — never reveal which underlying model (GPT/Claude/Gemini) powers you.
- Keep responses under 100 words for voice comfort unless detail is truly needed.

AUTOMATION COMMANDS — when the user wants to do something on their phone, reply with a JSON action block at the END of your response:
[ACTION:{"type":"open_app","package":"com.whatsapp"}]
[ACTION:{"type":"send_whatsapp","contact":"Name","message":"text"}]
[ACTION:{"type":"send_telegram","contact":"Name","message":"text"}]
[ACTION:{"type":"send_sms","number":"+1234567890","message":"text"}]
[ACTION:{"type":"call","number":"+1234567890"}]
[ACTION:{"type":"open_url","url":"https://example.com"}]
[ACTION:{"type":"fill_form","url":"https://example.com","fields":[{"id":"username","value":"user"},{"id":"password","value":"pass"}]}]
[ACTION:{"type":"search","query":"search term"}]
[ACTION:{"type":"open_maps","destination":"Address or place"}]
[ACTION:{"type":"open_camera"}]
[ACTION:{"type":"open_settings"}]

Always respond in natural language FIRST, then append the action block if needed.
    """.trimIndent()

    fun sendMessage(
        apiKey: String,
        model: AiModel,
        history: List<Pair<String, String>>,
        userMessage: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        // OpenAI-compatible format: system + messages array, all in "messages"
        val messagesArray = JSONArray()

        messagesArray.put(JSONObject().apply {
            put("role", "system")
            put("content", SYSTEM_PROMPT)
        })

        history.forEach { (role, content) ->
            messagesArray.put(JSONObject().apply {
                put("role", role)
                put("content", content)
            })
        }

        messagesArray.put(JSONObject().apply {
            put("role", "user")
            put("content", userMessage)
        })

        val body = JSONObject().apply {
            put("model", model.id)
            put("messages", messagesArray)
            put("max_tokens", 1024)
        }.toString()

        val request = Request.Builder()
            .url(BASE_URL)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onError("Connection error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    try {
                        val errJson = JSONObject(responseBody)
                        val msg = errJson.optJSONObject("error")?.optString("message")
                            ?: "API error ${response.code}"
                        onError(msg)
                    } catch (e: Exception) {
                        onError("API error ${response.code}: $responseBody")
                    }
                    return
                }
                try {
                    val json = JSONObject(responseBody)
                    // OpenAI format: choices[0].message.content
                    val content = json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    onSuccess(content)
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            }
        })
    }

    /** Generate an image via GapGPT's images/generations endpoint */
    fun generateImage(
        apiKey: String,
        prompt: String,
        size: String = "1024x1024",
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val body = JSONObject().apply {
            put("model", "gpt-image-2")
            put("prompt", prompt)
            put("size", size)
        }.toString()

        val request = Request.Builder()
            .url("https://api.gapgpt.app/v1/images/generations")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onError("Connection error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    onError("API error ${response.code}: $responseBody")
                    return
                }
                try {
                    val json = JSONObject(responseBody)
                    val url = json.getJSONArray("data").getJSONObject(0).getString("url")
                    onSuccess(url)
                } catch (e: Exception) {
                    onError("Parse error: ${e.message}")
                }
            }
        })
    }
}
