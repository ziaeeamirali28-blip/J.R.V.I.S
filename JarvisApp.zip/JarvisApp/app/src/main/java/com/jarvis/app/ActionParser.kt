package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

object ActionParser {

    private val ACTION_REGEX = Regex("""\[ACTION:(\{.*?\})\]""", RegexOption.DOT_MATCHES_ALL)

    data class ParsedResponse(
        val spokenText: String,    // text to display & speak (no action blocks)
        val actions: List<JarvisAction>
    )

    sealed class JarvisAction {
        data class OpenApp(val pkg: String) : JarvisAction()
        data class SendWhatsApp(val contact: String, val message: String) : JarvisAction()
        data class SendTelegram(val contact: String, val message: String) : JarvisAction()
        data class SendSms(val number: String, val message: String) : JarvisAction()
        data class Call(val number: String) : JarvisAction()
        data class OpenUrl(val url: String) : JarvisAction()
        data class FillForm(val url: String, val fields: List<Pair<String, String>>) : JarvisAction()
        data class Search(val query: String) : JarvisAction()
        data class OpenMaps(val destination: String) : JarvisAction()
        object OpenCamera : JarvisAction()
        object OpenSettings : JarvisAction()
    }

    fun parse(rawResponse: String): ParsedResponse {
        val actions = mutableListOf<JarvisAction>()
        val matches = ACTION_REGEX.findAll(rawResponse)

        matches.forEach { match ->
            try {
                val json = JSONObject(match.groupValues[1])
                val action = when (json.getString("type")) {
                    "open_app" -> JarvisAction.OpenApp(json.getString("package"))
                    "send_whatsapp" -> JarvisAction.SendWhatsApp(
                        json.getString("contact"), json.getString("message")
                    )
                    "send_telegram" -> JarvisAction.SendTelegram(
                        json.getString("contact"), json.getString("message")
                    )
                    "send_sms" -> JarvisAction.SendSms(
                        json.getString("number"), json.getString("message")
                    )
                    "call" -> JarvisAction.Call(json.getString("number"))
                    "open_url" -> JarvisAction.OpenUrl(json.getString("url"))
                    "fill_form" -> {
                        val fieldsArray = json.getJSONArray("fields")
                        val fields = (0 until fieldsArray.length()).map { i ->
                            val f = fieldsArray.getJSONObject(i)
                            Pair(f.getString("id"), f.getString("value"))
                        }
                        JarvisAction.FillForm(json.getString("url"), fields)
                    }
                    "search" -> JarvisAction.Search(json.getString("query"))
                    "open_maps" -> JarvisAction.OpenMaps(json.getString("destination"))
                    "open_camera" -> JarvisAction.OpenCamera
                    "open_settings" -> JarvisAction.OpenSettings
                    else -> null
                }
                action?.let { actions.add(it) }
            } catch (e: Exception) {
                // skip malformed action
            }
        }

        val cleanText = rawResponse.replace(ACTION_REGEX, "").trim()
        return ParsedResponse(cleanText, actions)
    }

    fun execute(context: Context, action: JarvisAction) {
        val svc = JarvisAccessibilityService.instance

        when (action) {
            is JarvisAction.OpenApp -> {
                val intent = context.packageManager.getLaunchIntentForPackage(action.pkg)
                    ?: return
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.SendWhatsApp -> {
                if (svc != null) {
                    svc.sendWhatsApp(action.contact, action.message)
                } else {
                    // Fallback: use WhatsApp URI scheme (opens WhatsApp with text pre-filled)
                    val url = "https://wa.me/?text=${Uri.encode(action.message)}"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }
            }

            is JarvisAction.SendTelegram -> {
                if (svc != null) {
                    svc.sendTelegram(action.contact, action.message)
                } else {
                    val intent = Intent(Intent.ACTION_VIEW,
                        Uri.parse("tg://msg?text=${Uri.encode(action.message)}"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }
            }

            is JarvisAction.SendSms -> {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:${action.number}")
                    putExtra("sms_body", action.message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }

            is JarvisAction.Call -> {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${action.number}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.OpenUrl -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(action.url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.FillForm -> {
                // Open URL first, then fill after delay
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(action.url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                svc?.fillWebForm(action.fields, delayMs = 2500)
            }

            is JarvisAction.Search -> {
                val intent = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=${Uri.encode(action.query)}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.OpenMaps -> {
                val intent = Intent(Intent.ACTION_VIEW,
                    Uri.parse("geo:0,0?q=${Uri.encode(action.destination)}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.OpenCamera -> {
                val intent = Intent("android.media.action.IMAGE_CAPTURE")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }

            is JarvisAction.OpenSettings -> {
                val intent = Intent(Settings.ACTION_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
    }
}
