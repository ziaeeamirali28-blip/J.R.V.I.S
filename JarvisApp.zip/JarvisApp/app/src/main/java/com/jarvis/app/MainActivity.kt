package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import kotlinx.coroutines.*
import java.util.*

class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var tvStatus: TextView
    private lateinit var tvArcLabel: TextView
    private lateinit var tvAccessibilityWarning: TextView
    private lateinit var btnArcReactor: View
    private lateinit var btnMic: ImageButton
    private lateinit var btnSend: Button
    private lateinit var etInput: EditText
    private lateinit var chatContainer: LinearLayout
    private lateinit var scrollChat: ScrollView
    private lateinit var quickActionsContainer: LinearLayout

    // State
    private var apiKey = ""
    private var selectedModel = AiApi.AiModel.GPT4O
    private var isListening = false
    private var isSpeaking = false
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    // Speech
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // Quick actions
    private val quickActions = listOf(
        "⏱" to "What time is it?",
        "📰" to "Latest news headlines",
        "😄" to "Tell me a joke",
        "🔍" to "Search Google for something",
        "📧" to "Open my email",
        "📞" to "Call someone",
        "💬" to "Send a WhatsApp message",
        "🗺" to "Open Maps",
        "📷" to "Open camera",
        "⚙" to "Open settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupQuickActions()
        setupTts()
        requestPermissions()
        promptApiKey()

        btnSend.setOnClickListener { sendMessage() }
        etInput.setOnEditorActionListener { _, _, _ -> sendMessage(); true }
        btnMic.setOnClickListener { toggleListen() }
        btnArcReactor.setOnClickListener { toggleListen() }
        btnArcReactor.setOnLongClickListener {
            if (apiKey.isNotEmpty()) promptModelSelection()
            true
        }
        tvAccessibilityWarning.setOnClickListener { openAccessibilitySettings() }

        checkAccessibilityStatus()
    }

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvArcLabel = findViewById(R.id.tvArcLabel)
        tvAccessibilityWarning = findViewById(R.id.tvAccessibilityWarning)
        btnArcReactor = findViewById(R.id.btnArcReactor)
        btnMic = findViewById(R.id.btnMic)
        btnSend = findViewById(R.id.btnSend)
        etInput = findViewById(R.id.etInput)
        chatContainer = findViewById(R.id.chatContainer)
        scrollChat = findViewById(R.id.scrollChat)
        quickActionsContainer = findViewById(R.id.quickActionsContainer)
    }

    // ─── API Key ─────────────────────────────────────────────

    private fun promptApiKey() {
        // Try loading saved key first
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val saved = prefs.getString("api_key", "") ?: ""
        val savedModel = prefs.getString("selected_model", "") ?: ""
        if (saved.isNotEmpty()) {
            apiKey = saved
            selectedModel = AiApi.AiModel.values().find { it.name == savedModel } ?: AiApi.AiModel.GPT4O
            onReady()
            return
        }

        val input = EditText(this).apply {
            hint = "GapGPT API Key..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(40)
        }

        AlertDialog.Builder(this)
            .setTitle("⚡ JARVIS INITIALIZATION")
            .setMessage("Enter your GapGPT API key to activate JARVIS.\n(Get one at gapgpt.app — works with GPT, Claude & Gemini)")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("ACTIVATE") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isNotEmpty()) {
                    apiKey = key
                    prefs.edit().putString("api_key", key).apply()
                    promptModelSelection()
                } else {
                    Toast.makeText(this, "Please enter a valid API key", Toast.LENGTH_SHORT).show()
                    promptApiKey()
                }
            }
            .show()
    }

    private fun promptModelSelection() {
        val models = AiApi.AiModel.values()
        val names = models.map { it.displayName }.toTypedArray()
        var selectedIndex = 0

        AlertDialog.Builder(this)
            .setTitle("🧠 SELECT AI BRAIN")
            .setSingleChoiceItems(names, selectedIndex) { _, which -> selectedIndex = which }
            .setCancelable(false)
            .setPositiveButton("CONFIRM") { _, _ ->
                selectedModel = models[selectedIndex]
                getSharedPreferences("jarvis", MODE_PRIVATE)
                    .edit().putString("selected_model", selectedModel.name).apply()
                onReady()
            }
            .show()
    }

    private fun onReady() {
        updateStatus("ONLINE · ${selectedModel.displayName} · READY")
        speak("Good day. J.A.R.V.I.S online. All systems nominal. How may I assist you today, sir?")
        addMessage("jarvis", "Good day. J.A.R.V.I.S online. All systems nominal. How may I assist you today?")
    }

    // ─── Send Message ─────────────────────────────────────────

    private fun sendMessage() {
        val text = etInput.text.toString().trim()
        if (text.isEmpty() || apiKey.isEmpty()) return
        etInput.setText("")

        addMessage("user", text)
        updateStatus("PROCESSING...")
        val thinkingView = addThinkingDots()

        AiApi.sendMessage(
            apiKey = apiKey,
            model = selectedModel,
            history = conversationHistory.toList(),
            userMessage = text,
            onSuccess = { raw ->
                runOnUiThread {
                    thinkingView.parent?.let { (it as LinearLayout).removeView(thinkingView) }
                    val parsed = ActionParser.parse(raw)
                    conversationHistory.add(Pair("user", text))
                    conversationHistory.add(Pair("assistant", raw))
                    if (conversationHistory.size > 20) {
                        conversationHistory.removeAt(0)
                        conversationHistory.removeAt(0)
                    }
                    addMessage("jarvis", parsed.spokenText)
                    speak(parsed.spokenText)
                    updateStatus("READY")
                    parsed.actions.forEach { action ->
                        ActionParser.execute(applicationContext, action)
                    }
                }
            },
            onError = { err ->
                runOnUiThread {
                    thinkingView.parent?.let { (it as LinearLayout).removeView(thinkingView) }
                    addMessage("jarvis", "I'm experiencing a technical difficulty, sir: $err")
                    speak("I'm experiencing a technical difficulty, sir.")
                    updateStatus("ERROR")
                }
            }
        )
    }

    // ─── Speech Recognition ───────────────────────────────────

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotEmpty()) {
                    etInput.setText(text)
                    sendMessage()
                }
                stopListening()
            }
            override fun onError(error: Int) { stopListening() }
            override fun onReadyForSpeech(params: Bundle?) {
                tvArcLabel.text = "LISTENING..."
                updateStatus("LISTENING · SPEAK NOW")
            }
            override fun onEndOfSpeech() { stopListening() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun toggleListen() {
        if (isListening) stopListening()
        else startListening()
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (isSpeaking) tts?.stop()
        if (speechRecognizer == null) setupSpeechRecognizer()
        isListening = true
        btnMic.setColorFilter(getColor(android.R.color.holo_red_light))
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun stopListening() {
        isListening = false
        speechRecognizer?.stopListening()
        btnMic.clearColorFilter()
        tvArcLabel.text = "TAP TO SPEAK"
        updateStatus(if (apiKey.isNotEmpty()) "READY" else "AWAITING INITIALIZATION")
    }

    // ─── TTS ─────────────────────────────────────────────────

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                // Prefer en-GB for JARVIS British accent
                val result = tts?.setLanguage(Locale.UK)
                if (result == TextToSpeech.LANG_NOT_SUPPORTED ||
                    result == TextToSpeech.LANG_MISSING_DATA) {
                    tts?.language = Locale.US
                }
                tts?.setSpeechRate(0.95f)
                tts?.setPitch(0.85f)
            }
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        val clean = text.replace(Regex("\\[ACTION:[^\\]]+\\]"), "")
            .replace(Regex("[*_#`]"), "")
            .trim()
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt")
        isSpeaking = true
    }

    // ─── Chat UI ──────────────────────────────────────────────

    private fun addMessage(role: String, text: String) {
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 8
                bottomMargin = 8
                if (role == "user") {
                    gravity = Gravity.END
                    marginStart = 80
                    marginEnd = 0
                } else {
                    gravity = Gravity.START
                    marginStart = 0
                    marginEnd = 80
                }
            }
            layoutParams = params
            background = ContextCompat.getDrawable(
                this@MainActivity,
                if (role == "user") R.drawable.btn_outline else R.drawable.input_bg
            )
        }

        val label = TextView(this).apply {
            text = if (role == "user") "YOU" else "J.A.R.V.I.S"
            textSize = 8f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.jarvis_blue))
            letterSpacing = 0.2f
            setPadding(0, 0, 0, 6)
        }

        val content = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(0xFFCCF0FF.toInt())
            lineHeight = (textSize * 1.5).toInt()
        }

        bubble.addView(label)
        bubble.addView(content)

        val wrapper = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            gravity = if (role == "user") Gravity.END else Gravity.START
            addView(bubble)
        }

        chatContainer.addView(wrapper)
        scrollChat.post { scrollChat.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun addThinkingDots(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24)
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 8 }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.input_bg)
        }
        repeat(3) {
            val dot = View(this).apply {
                val dp8 = (8 * resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(dp8, dp8).apply { marginEnd = dp8 / 2 }
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.arc_reactor_bg)
                alpha = 0.3f
            }
            row.addView(dot)
        }
        val wrapper = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            gravity = Gravity.START
            addView(row)
        }
        chatContainer.addView(wrapper)
        scrollChat.post { scrollChat.fullScroll(ScrollView.FOCUS_DOWN) }
        return wrapper
    }

    private fun setupQuickActions() {
        quickActions.forEach { (emoji, command) ->
            val btn = Button(this).apply {
                text = "$emoji"
                textSize = 18f
                setPadding(12, 8, 12, 8)
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.btn_outline)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.jarvis_blue))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = 8 }
                layoutParams = lp
                setOnClickListener {
                    etInput.setText(command)
                    sendMessage()
                }
            }
            quickActionsContainer.addView(btn)
        }
    }

    // ─── Accessibility ────────────────────────────────────────

    private fun checkAccessibilityStatus() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (!JarvisAccessibilityService.isRunning) {
                tvAccessibilityWarning.visibility = View.VISIBLE
            } else {
                tvAccessibilityWarning.visibility = View.GONE
            }
            checkAccessibilityStatus()
        }, 3000)
    }

    private fun openAccessibilitySettings() {
        AlertDialog.Builder(this)
            .setTitle("Enable JARVIS Automation")
            .setMessage("To allow JARVIS to send messages and control apps on your behalf:\n\n1. Tap OK to open Accessibility Settings\n2. Find 'JARVIS Automation'\n3. Enable it")
            .setPositiveButton("OPEN SETTINGS") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("LATER", null)
            .show()
    }

    // ─── Helpers ─────────────────────────────────────────────

    private fun updateStatus(msg: String) {
        tvStatus.text = msg
    }

    private fun requestPermissions() {
        val perms = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
