# ⚡ JARVIS Android App

A full-featured AI assistant with real phone automation, powered by **GapGPT** —
giving you access to GPT-4o, Claude, and Gemini all through ONE API key.

## Features
- 🎤 Voice input + Text-to-Speech (British accent)
- 🧠 Switch between GPT-4o / Claude Sonnet / Claude Opus / Gemini Pro / Gemini Flash
- 📱 Send WhatsApp & Telegram messages automatically
- 🌐 Open URLs & fill web forms
- 📞 Make calls, send SMS
- 🗺 Open Maps, Camera, Settings
- 🔍 Google Search
- 🎨 Image generation (gpt-image-2)
- 💾 API key + model choice saved on device

## Setup in Android Studio

1. Open Android Studio → File → Open → select this folder (JarvisApp)
2. Wait for Gradle sync to finish
3. Connect your Android phone (USB debugging ON) or use an emulator
4. Click Run ▶
5. On first launch:
   - Get a GapGPT API key at https://gapgpt.app (پنل توسعه‌دهندگان → کلیدهای API)
   - Enter the key in the app
   - Choose your preferred AI brain (GPT-4o, Claude, or Gemini)

## Switching AI models later
Long-press the ⚡ Arc Reactor button anytime to switch between GPT-4o, Claude, and Gemini.

## API Provider: GapGPT
This app uses GapGPT (https://gapgpt.app) — an OpenAI-compatible API gateway that
gives access to multiple providers through one key, with Persian documentation
and Rial payment support.

Base URL used: `https://api.gapgpt.app/v1/chat/completions`
(Alternative CDN endpoint: `https://api.gapapi.com/v1` — edit AiApi.kt if needed)

## Enable Automation (WhatsApp/Telegram/form filling)
After install:
1. Settings → Accessibility → Installed apps → JARVIS Automation → Enable
2. Now JARVIS can send messages and fill forms on your behalf

## How to use
- Tap the ⚡ button or microphone to speak
- Long-press ⚡ to switch AI model
- Type anything in the text box
- Quick action buttons at the bottom for common tasks

## Example commands
- "Send a WhatsApp to Mom saying I'll be late"
- "Open YouTube and search for lo-fi music"
- "Call +98912..."
- "Search Google for best restaurants near me"
- "Open Google Maps and navigate to Tehran Grand Bazaar"
- "Fill in my login on gmail.com" (with form filling enabled)

## Requirements
- Android 8.0 (API 26) or higher
- GapGPT API key (gapgpt.app)
- Internet connection

## Project Structure
```
app/src/main/java/com/jarvis/app/
├── MainActivity.kt          # Main UI + speech + TTS + model picker
├── AiApi.kt                 # GapGPT API calls (GPT/Claude/Gemini via one endpoint)
├── ActionParser.kt          # Parses Claude's action commands
└── JarvisAccessibilityService.kt  # Phone automation engine
```

## Cost management
Each model has different pricing. Check your usage at gapgpt.app dashboard
(بخش آمار استفاده) to monitor costs across whichever model you're using.
